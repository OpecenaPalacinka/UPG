#!/bin/bash
java -cp ./bin:./WaterFlowSim.jar L01_SpusteniSimulatoru $@
