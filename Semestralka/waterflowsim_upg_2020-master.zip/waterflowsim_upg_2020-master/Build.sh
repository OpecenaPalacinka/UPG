#!/bin/bash
mkdir ./bin
javac -cp ./src:./WaterFlowSim.jar -encoding UTF-8 -d ./bin src/*.java
